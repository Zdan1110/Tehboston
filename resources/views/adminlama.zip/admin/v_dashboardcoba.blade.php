@extends('admin.templatecoba')

@section('title', 'Dashboard')

@section('content')
  <h1 class="text-2xl font-semibold mb-6">Dashboard</h1>

  <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    <!-- Contoh Chart -->
    <div class="bg-white rounded-lg p-6 shadow">
      <h2 class="text-lg font-bold mb-2">Penjualan Tertinggi</h2>
      <!-- Placeholder chart -->
      <div class="h-40 bg-gray-100 flex items-center justify-center text-gray-400">[Chart]</div>
    </div>

    <div class="bg-white rounded-lg p-6 shadow">
      <h2 class="text-lg font-bold mb-2">Franchise Aktif</h2>
      <div class="h-40 bg-gray-100 flex items-center justify-center text-gray-400">[Chart]</div>
    </div>

    <div class="bg-white rounded-lg p-6 shadow">
      <h2 class="text-lg font-bold mb-2">Survey Terbaru</h2>
      <div class="h-40 bg-gray-100 flex items-center justify-center text-gray-400">[Chart]</div>
    </div>
  </div>
@endsection
